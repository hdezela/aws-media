//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by utv_core.rc
//
#define IDD_UL00_CONFIG                 101
#define IDD_GLOBAL_CONFIG               129
#define IDD_UQ00_CONFIG                 130
#define IDC_DIVIDE_COUNT_EDIT           1001
#define IDC_SAVE_CONFIG_CHECK           1001
#define IDC_ASSUME_INTERLACE_CHECK      1002
#define IDC_IGNORE_SET_CONFIG_CHECK     1002
#define IDC_INTRAFRAME_PREDICT_WRONG_MEDIAN_RADIO 1003
#define IDC_INTRAFRAME_PREDICT_LEFT_RADIO 1004
#define IDC_DIVIDE_COUNT_IS_NUM_PROCESSORS 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
