#ifndef _TYPEDEFS_H
#define _TYPEDEFS_H

#include "ilbc.h"

#endif
